package mx.uv.facturas;

import org.springframework.data.repository.CrudRepository;

public interface IFacturas extends CrudRepository<Facturas,Integer> {
}

package mx.uv.facturas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturasApplicationTests {

	@Test
	void contextLoads() {
	}

}
